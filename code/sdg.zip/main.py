import os
import pandas as pd
from s3_util import s3Handler
from report_generator import preprocess


def handler():
    s3_help = s3Handler()
    last_two_weeks_file = s3_help.list_object[-2:]
    last_week,current_week = last_two_weeks_file
    report_dir, df = preprocess(last_week,current_week,last_two_weeks_file)
    s3_help.upload(df,report_dir)
    